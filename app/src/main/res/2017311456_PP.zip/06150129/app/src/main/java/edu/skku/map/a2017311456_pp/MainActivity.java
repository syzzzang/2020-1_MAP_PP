package edu.skku.map.a2017311456_pp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Iterator;


public class MainActivity extends AppCompatActivity {
    private DatabaseReference mpostReference;
    EditText userid, password;
    String lguserid="", lgpassword="";
    String jjinid="";
    private Bundle results;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        if(getIntent().getExtras() != null){
            EditText username = (EditText)findViewById(R.id.userid);
            Intent signupIntent = getIntent();
            username.setText(signupIntent.getStringExtra("Username"));
        }



        Button login = (Button)findViewById(R.id.loginButton);
        userid=(EditText)findViewById(R.id.userid);
        password=(EditText)findViewById(R.id.password);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lguserid=userid.getText().toString();
                lgpassword=password.getText().toString();
                if((lguserid.length()*lgpassword.length())==0){
                    Toast.makeText(MainActivity.this,"빈칸있써",Toast.LENGTH_SHORT).show();
                }else{
                    checkId(lguserid,lgpassword);
                }

            }
        });

        TextView signup = (TextView)findViewById(R.id.signup);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signupIntent = new Intent(MainActivity.this, SignUp.class);
                startActivity(signupIntent);
            }
        });


    }


    public void checkId(final String userid, final String password){
        DatabaseReference pref= FirebaseDatabase.getInstance().getReference("user_list").child(userid);

        ValueEventListener valueEventListener=new ValueEventListener() {
            //boolean a=true;
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){

                    checkpw(userid,password);
                }else{
                    Toast.makeText(MainActivity.this,"Wrong Username",Toast.LENGTH_SHORT).show();
                }

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        pref.addListenerForSingleValueEvent(valueEventListener);

    }
    public void checkpw(final String id, final String pw){
        DatabaseReference pref= FirebaseDatabase.getInstance().getReference("user_list").child(id);//.child("password");
        //String is=id;
        ValueEventListener valueEventListener=new ValueEventListener() {
            //boolean a=true;
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("password").getValue(String.class).equals(pw)){
                    Toast.makeText(MainActivity.this,"로그인 성공!",Toast.LENGTH_SHORT).show();
                    jjinid=id;

                    Intent loginIntent = new Intent(MainActivity.this, postPage.class);
                    //loginIntent.putExtra("Username", id);
                    loginIntent.putExtra("Username",dataSnapshot.child("name").getValue().toString());
                    loginIntent.putExtra("Userfullname",dataSnapshot.child("fullname").getValue().toString());
                    loginIntent.putExtra("Useremail",dataSnapshot.child("email").getValue().toString());
                    loginIntent.putExtra("Userbirth",dataSnapshot.child("birth").getValue().toString());

                    startActivity(loginIntent);
                }else{
                    Toast.makeText(MainActivity.this,"Wrong Password",Toast.LENGTH_SHORT).show();
                }

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        pref.addListenerForSingleValueEvent(valueEventListener);
    }




}

